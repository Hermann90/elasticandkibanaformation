# Documentation

## Description

Ce projet est un exemple de configuration d'un cluster Elasticsearch avec Kibana.

## Installation

```bash
docker compose up -d
```

## Vérification

1. Se connecter à [https://localhost:9200/](https://localhost:9200/)
2. Se connecter avec les identifiants suivants:
    - Username: `elastic`
    - Password: `changeme`
3. Vérifier que le serveur Elasticsearch est bien en ligne

## Usage

1. Ouvrir un navigateur web
2. Aller à l'adresse [https://localhost:5601](https://localhost:5601)
3. Se connecter avec les identifiants suivants:
    - Username: `elastic`
    - Password: `changeme`

4. Tester l'adresse [https://localhost:9200/_cat/nodes?v](localhost:9200/_cat/nodes?v) pour vérifier que l'ensemble des noeuds sont bien en ligne



## Injection de données

1. Ouvrir un terminal

Après avoir créer l'index __products__ et récupérer l'ApiKey, vous pouvez injecter des données dans l'index __products__ avec la commande suivante :

```bash
curl -k -X POST "https://localhost:9200/products/_bulk?pretty" \
  -H "Authorization: ApiKey ZGE2X1Y1VUJ4ZUk2M3JDR05PbGI6bGNUTGdHYnRUY202bnJBenlIWFZWQQ==" \
  -H "Content-Type: application/json" \
  --data-binary "@data/products-bulk.json"
```

Vérifiez que les données ont bien été injectées en allant sur [https://localhost:9200/products/_search?pretty](https://localhost:9200/products/_search?pretty)

Vérifier le mapping de l'index __products__ en allant sur [https://localhost:9200/products/_mapping?pretty](https://localhost:9200/products/_mapping?pretty)

## Informations utiles

- Lister les index : [https://localhost:9200/_cat/indices?v](https://localhost:9200/_cat/indices?v)
- Lister les noeuds : [https://localhost:9200/_cat/nodes?v](https://localhost:9200/_cat/nodes?v)
- Lister les shards : [https://localhost:9200/_cat/shards?v](https://localhost:9200/_cat/shards?v)
- Lister les templates : [https://localhost:9200/_cat/templates?v](https://localhost:9200/_cat/templates?v)


## K6

Lien : [K6 téléchargement et documentation](https://github.com/grafana/k6-studio/releases)
